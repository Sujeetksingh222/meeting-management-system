class Action < ApplicationRecord
  belongs_to :mom
end
