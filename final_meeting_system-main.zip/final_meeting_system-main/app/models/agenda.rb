class Agenda < ApplicationRecord
    belongs_to :meet
end
